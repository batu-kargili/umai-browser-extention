"use strict";
(() => {
  // src/popup/popup.ts
  var DEFAULT_CONTROL_CENTER_URL = "https://pocttconsole.umaisolutions.com";
  var CONTROL_CENTER_CONNECT_PATH = "/extension/connect";
  function byId(id) {
    const element = document.getElementById(id);
    if (!element) {
      throw new Error(`Missing popup element: ${id}`);
    }
    return element;
  }
  function setStatus(text, tone) {
    const element = byId("statusText");
    element.textContent = text;
    element.className = `status ${tone}`;
  }
  function safeControlCenterUrl(state) {
    if (!state?.configured || !state.config?.controlCenterUrl) {
      return DEFAULT_CONTROL_CENTER_URL;
    }
    try {
      return new URL(state.config.controlCenterUrl).origin;
    } catch (_error) {
      return DEFAULT_CONTROL_CENTER_URL;
    }
  }
  function sendInternalMessage(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, (response) => {
        const runtimeError = chrome.runtime.lastError;
        if (runtimeError) {
          reject(new Error(runtimeError.message));
          return;
        }
        resolve(response);
      });
    });
  }
  async function loadRuntimeState() {
    const response = await sendInternalMessage({ type: "GET_CONFIG" });
    if (!response.ok || !response.config) {
      return null;
    }
    return response.config;
  }
  function renderState(state) {
    const tenantValue = byId("tenantValue");
    const userValue = byId("userValue");
    const endpointValue = byId("endpointValue");
    const guardValue = byId("guardValue");
    const approvedValue = byId("approvedValue");
    if (!state || !state.configured || !state.config) {
      tenantValue.textContent = "-";
      userValue.textContent = "-";
      endpointValue.textContent = "-";
      guardValue.textContent = "Fail-closed";
      approvedValue.textContent = "Connect organization";
      setStatus("Not connected. Use Connect organization.", "warn");
      return;
    }
    tenantValue.textContent = state.config.tenantId;
    userValue.textContent = state.config.userEmail ?? state.config.userDisplayName ?? "-";
    endpointValue.textContent = state.config.ingestBaseUrl;
    guardValue.textContent = state.config.browserSecurity.enabled ? state.config.browserSecurity.mode === "audit" ? "Audit" : "Enforce" : "Off";
    approvedValue.textContent = state.config.allowedDomains.length > 0 ? state.config.allowedDomains.join(", ") : "-";
    setStatus("Connected to organization.", "ok");
  }
  async function refresh() {
    try {
      const state = await loadRuntimeState();
      renderState(state);
      return state;
    } catch (error) {
      const text = error instanceof Error ? error.message : "Failed to read extension state.";
      setStatus(text, "error");
      return null;
    }
  }
  async function openControlCenterConnect() {
    const state = await refresh();
    const controlCenterUrl = safeControlCenterUrl(state ?? void 0);
    const next = new URL(CONTROL_CENTER_CONNECT_PATH, controlCenterUrl);
    next.searchParams.set("extId", chrome.runtime.id);
    chrome.tabs.create({ url: next.toString() });
    window.close();
  }
  async function disconnect() {
    try {
      const response = await sendInternalMessage({ type: "DISCONNECT_LOCAL_CONFIG" });
      if (!response.ok) {
        setStatus(response.error ?? "Failed to disconnect local connection.", "error");
        return;
      }
      renderState(response.config ?? null);
    } catch (error) {
      const text = error instanceof Error ? error.message : "Disconnect failed.";
      setStatus(text, "error");
    }
  }
  function init() {
    byId("connectButton").addEventListener("click", () => {
      void openControlCenterConnect();
    });
    byId("disconnectButton").addEventListener("click", () => {
      void disconnect();
    });
    byId("refreshButton").addEventListener("click", () => {
      void refresh();
    });
    void refresh();
  }
  document.addEventListener("DOMContentLoaded", init);
})();
//# sourceMappingURL=popup.js.map
