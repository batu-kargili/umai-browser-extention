"use strict";
(() => {
  // src/content/adapter_base.ts
  function queryFirst(selectors) {
    for (const selector of selectors) {
      const node = document.querySelector(selector);
      if (node instanceof HTMLElement) {
        return node;
      }
    }
    return null;
  }
  function editableFromElement(element) {
    if (element instanceof HTMLTextAreaElement || element instanceof HTMLInputElement) {
      return element.value;
    }
    return (element.textContent ?? "").trim();
  }
  function setEditableValue(element, next) {
    if (element instanceof HTMLTextAreaElement || element instanceof HTMLInputElement) {
      element.value = next;
      element.dispatchEvent(new Event("input", { bubbles: true }));
      return;
    }
    element.textContent = next;
    element.dispatchEvent(new InputEvent("input", { bubbles: true, data: next }));
  }
  function createSiteAdapter(siteId, selectors) {
    return {
      siteId,
      locateInput() {
        const node = queryFirst(selectors.input);
        if (!node) {
          return null;
        }
        if (node instanceof HTMLTextAreaElement || node instanceof HTMLInputElement || node.isContentEditable) {
          return node;
        }
        return null;
      },
      locateSendButton() {
        return queryFirst(selectors.sendButton);
      },
      locateConversationRoot() {
        return queryFirst(selectors.conversationRoot);
      },
      locateAssistantMessages() {
        const results = [];
        for (const selector of selectors.assistantMessage) {
          const nodes = Array.from(document.querySelectorAll(selector));
          for (const node of nodes) {
            if (node instanceof HTMLElement && node.innerText.trim().length > 0) {
              results.push(node);
            }
          }
        }
        return results;
      },
      getPromptText() {
        const input = this.locateInput();
        if (!input) {
          return "";
        }
        return editableFromElement(input).trim();
      },
      setPromptText(next) {
        const input = this.locateInput();
        if (!input) {
          return;
        }
        setEditableValue(input, next);
      },
      submitPrompt() {
        const sendButton = this.locateSendButton();
        if (sendButton) {
          sendButton.click();
          return;
        }
        const input = this.locateInput();
        if (!input) {
          return;
        }
        input.dispatchEvent(
          new KeyboardEvent("keydown", {
            key: "Enter",
            bubbles: true,
            cancelable: true
          })
        );
      }
    };
  }

  // src/content/dom/attachments.ts
  var TEXT_EXTENSIONS = /* @__PURE__ */ new Set(["txt", "csv"]);
  var SERVER_EXTENSIONS = /* @__PURE__ */ new Set(["xlsx", "docx"]);
  var pendingFiles = [];
  function extensionFromName(name) {
    const idx = name.lastIndexOf(".");
    return idx >= 0 ? name.slice(idx + 1).trim().toLowerCase() : "";
  }
  function bytesToHex(bytes) {
    return Array.from(new Uint8Array(bytes), (value) => value.toString(16).padStart(2, "0")).join("");
  }
  async function sha256File(file) {
    try {
      const digest = await crypto.subtle.digest("SHA-256", await file.arrayBuffer());
      return bytesToHex(digest);
    } catch (_error) {
      return null;
    }
  }
  function arrayBufferToBase64(buffer) {
    const bytes = new Uint8Array(buffer);
    let binary = "";
    const chunkSize = 32768;
    for (let offset = 0; offset < bytes.length; offset += chunkSize) {
      const chunk = bytes.subarray(offset, offset + chunkSize);
      binary += String.fromCharCode(...chunk);
    }
    return btoa(binary);
  }
  async function readTextFile(file, maxExtractedChars) {
    const bytes = await file.slice(0, maxExtractedChars + 1).arrayBuffer();
    const text = new TextDecoder("utf-8", { fatal: false }).decode(bytes);
    return {
      text: text.slice(0, maxExtractedChars),
      truncated: text.length > maxExtractedChars || file.size > maxExtractedChars
    };
  }
  async function buildManifest(file, config) {
    const extension = extensionFromName(file.name);
    const base = {
      filename: file.name,
      mime: file.type || "application/octet-stream",
      extension,
      size_bytes: file.size,
      sha256: await sha256File(file),
      extracted_chars: 0,
      truncated: false
    };
    if (!config.supportedTypes.includes(extension)) {
      return {
        ...base,
        inspection_status: "unsupported"
      };
    }
    if (file.size > config.maxFileBytes) {
      return {
        ...base,
        inspection_status: "too_large"
      };
    }
    try {
      if (TEXT_EXTENSIONS.has(extension)) {
        const extracted = await readTextFile(file, config.maxExtractedChars);
        return {
          ...base,
          inspection_status: extracted.truncated ? "truncated" : "extracted",
          extracted_chars: extracted.text.length,
          truncated: extracted.truncated,
          extracted_text: extracted.text
        };
      }
      if (SERVER_EXTENSIONS.has(extension)) {
        return {
          ...base,
          inspection_status: "server_required",
          content_b64: arrayBufferToBase64(await file.arrayBuffer())
        };
      }
      return {
        ...base,
        inspection_status: "unsupported"
      };
    } catch (error) {
      return {
        ...base,
        inspection_status: "extraction_failed",
        error: error instanceof Error ? error.message : "Attachment extraction failed."
      };
    }
  }
  function rememberFiles(files) {
    pendingFiles = Array.from(files).filter((file) => file.size > 0);
  }
  function startAttachmentCapture() {
    document.addEventListener(
      "change",
      (event) => {
        const target = event.target;
        if (target instanceof HTMLInputElement && target.type === "file" && target.files) {
          rememberFiles(target.files);
        }
      },
      true
    );
    document.addEventListener(
      "drop",
      (event) => {
        const files = event.dataTransfer?.files;
        if (files && files.length > 0) {
          rememberFiles(files);
        }
      },
      true
    );
  }
  async function getPendingAttachmentManifests(config) {
    if (!config.enabled || pendingFiles.length === 0) {
      return [];
    }
    return Promise.all(pendingFiles.map((file) => buildManifest(file, config)));
  }

  // src/content/dom/observer.ts
  function observeStableAssistantText(options) {
    const stabilityMs = options.stabilityMs ?? 1200;
    let timeoutId = null;
    let lastSeen = "";
    let lastEmitted = "";
    const schedule = () => {
      const next = options.getLatestText().trim();
      if (!next || next === lastSeen) {
        return;
      }
      lastSeen = next;
      if (timeoutId !== null) {
        window.clearTimeout(timeoutId);
      }
      timeoutId = window.setTimeout(() => {
        if (lastSeen && lastSeen !== lastEmitted) {
          lastEmitted = lastSeen;
          options.onStable(lastSeen);
        }
      }, stabilityMs);
    };
    const observer = new MutationObserver(() => {
      schedule();
    });
    observer.observe(options.root, {
      subtree: true,
      childList: true,
      characterData: true
    });
    schedule();
    return () => {
      observer.disconnect();
      if (timeoutId !== null) {
        window.clearTimeout(timeoutId);
      }
    };
  }

  // src/content/ui/overlay.ts
  var styleInjected = false;
  var toastRoot = null;
  function ensureStyle() {
    if (styleInjected) {
      return;
    }
    styleInjected = true;
    const style = document.createElement("style");
    style.id = "umai-extension-style";
    style.textContent = `
    .umai-toast-root {
      position: fixed;
      top: 16px;
      right: 16px;
      z-index: 2147483647;
      display: flex;
      flex-direction: column;
      gap: 8px;
      pointer-events: none;
    }
    .umai-toast {
      max-width: 360px;
      border-radius: 10px;
      border: 1px solid #1e293b;
      background: #0f172a;
      color: #f8fafc;
      box-shadow: 0 12px 32px rgba(15, 23, 42, 0.35);
      padding: 10px 12px;
      font: 600 12px/1.4 Arial, sans-serif;
      letter-spacing: 0.01em;
      pointer-events: auto;
    }
    .umai-toast.warn {
      border-color: #f59e0b;
      background: #78350f;
    }
    .umai-toast.block {
      border-color: #ef4444;
      background: #7f1d1d;
    }
    .umai-toast.ok {
      border-color: #22c55e;
      background: #14532d;
    }
  `;
    document.documentElement.appendChild(style);
  }
  function ensureRoot() {
    ensureStyle();
    if (!toastRoot) {
      toastRoot = document.createElement("div");
      toastRoot.className = "umai-toast-root";
      document.documentElement.appendChild(toastRoot);
    }
    return toastRoot;
  }
  function showToast(message, tone = "ok") {
    const root = ensureRoot();
    const item = document.createElement("div");
    item.className = `umai-toast ${tone}`;
    item.textContent = message;
    root.appendChild(item);
    setTimeout(() => {
      item.remove();
    }, 3200);
  }

  // src/content/ui/modal.ts
  var styleInjected2 = false;
  function ensureStyles() {
    if (styleInjected2) {
      return;
    }
    styleInjected2 = true;
    const style = document.createElement("style");
    style.id = "umai-modal-style";
    style.textContent = `
    .umai-modal-backdrop {
      position: fixed;
      inset: 0;
      background: rgba(2, 6, 23, 0.65);
      z-index: 2147483647;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 16px;
    }
    .umai-modal {
      width: min(720px, 100%);
      max-height: 84vh;
      overflow: auto;
      border-radius: 14px;
      border: 1px solid #cbd5e1;
      background: #f8fafc;
      color: #0f172a;
      box-shadow: 0 20px 48px rgba(15, 23, 42, 0.35);
      font-family: Arial, sans-serif;
    }
    .umai-modal-header {
      padding: 16px 18px 10px;
      border-bottom: 1px solid #e2e8f0;
    }
    .umai-modal-header h2 {
      margin: 0;
      font-size: 16px;
      line-height: 1.3;
    }
    .umai-modal-content {
      padding: 14px 18px;
      font-size: 13px;
      line-height: 1.5;
      color: #1e293b;
    }
    .umai-modal-details {
      margin-top: 10px;
      padding-left: 16px;
    }
    .umai-modal-compare {
      margin-top: 12px;
      border: 1px solid #cbd5e1;
      border-radius: 10px;
      background: #ffffff;
      overflow: hidden;
    }
    .umai-modal-compare pre {
      margin: 0;
      padding: 10px 12px;
      font-size: 12px;
      line-height: 1.45;
      white-space: pre-wrap;
      word-break: break-word;
      border-top: 1px solid #e2e8f0;
    }
    .umai-modal-compare-label {
      margin: 0;
      padding: 6px 12px;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      background: #f1f5f9;
      color: #334155;
    }
    .umai-modal-textarea {
      margin-top: 10px;
      width: 100%;
      min-height: 100px;
      resize: vertical;
      border: 1px solid #94a3b8;
      border-radius: 10px;
      padding: 8px 10px;
      font: 13px/1.45 Arial, sans-serif;
      color: #0f172a;
      background: #ffffff;
      box-sizing: border-box;
    }
    .umai-modal-footer {
      padding: 12px 18px 16px;
      display: flex;
      justify-content: flex-end;
      gap: 10px;
    }
    .umai-modal-btn {
      border-radius: 9px;
      border: 1px solid #94a3b8;
      background: #ffffff;
      color: #1e293b;
      font: 600 12px/1 Arial, sans-serif;
      padding: 10px 14px;
      cursor: pointer;
    }
    .umai-modal-btn.primary {
      background: #0f172a;
      color: #f8fafc;
      border-color: #0f172a;
    }
    .umai-modal-btn:disabled {
      cursor: not-allowed;
      opacity: 0.5;
    }
  `;
    document.documentElement.appendChild(style);
  }
  function createModal(options) {
    ensureStyles();
    return new Promise((resolve) => {
      const backdrop = document.createElement("div");
      backdrop.className = "umai-modal-backdrop";
      const modal = document.createElement("div");
      modal.className = "umai-modal";
      const header = document.createElement("div");
      header.className = "umai-modal-header";
      const title = document.createElement("h2");
      title.textContent = options.title;
      header.appendChild(title);
      const content = document.createElement("div");
      content.className = "umai-modal-content";
      const message = document.createElement("p");
      message.textContent = options.message;
      content.appendChild(message);
      let textarea = null;
      if (options.details && options.details.length > 0) {
        const list = document.createElement("ul");
        list.className = "umai-modal-details";
        for (const item of options.details) {
          const li = document.createElement("li");
          li.textContent = item;
          list.appendChild(li);
        }
        content.appendChild(list);
      }
      if (options.compareBefore !== void 0 && options.compareAfter !== void 0) {
        const compare = document.createElement("div");
        compare.className = "umai-modal-compare";
        const beforeLabel = document.createElement("p");
        beforeLabel.className = "umai-modal-compare-label";
        beforeLabel.textContent = "Original";
        compare.appendChild(beforeLabel);
        const beforeText = document.createElement("pre");
        beforeText.textContent = options.compareBefore;
        compare.appendChild(beforeText);
        const afterLabel = document.createElement("p");
        afterLabel.className = "umai-modal-compare-label";
        afterLabel.textContent = "Redacted";
        compare.appendChild(afterLabel);
        const afterText = document.createElement("pre");
        afterText.textContent = options.compareAfter;
        compare.appendChild(afterText);
        content.appendChild(compare);
      }
      if (options.textareaLabel) {
        const label = document.createElement("label");
        label.textContent = options.textareaLabel;
        label.style.display = "block";
        label.style.marginTop = "10px";
        label.style.fontWeight = "700";
        content.appendChild(label);
        textarea = document.createElement("textarea");
        textarea.className = "umai-modal-textarea";
        textarea.placeholder = options.textareaPlaceholder ?? "";
        content.appendChild(textarea);
      }
      const footer = document.createElement("div");
      footer.className = "umai-modal-footer";
      const secondary = document.createElement("button");
      secondary.className = "umai-modal-btn";
      secondary.textContent = options.secondaryLabel ?? "Edit";
      const primary = document.createElement("button");
      primary.className = "umai-modal-btn primary";
      primary.textContent = options.primaryLabel ?? "Proceed";
      const finish = (result) => {
        backdrop.remove();
        resolve(result);
      };
      secondary.addEventListener("click", () => finish({ action: "secondary" }));
      primary.addEventListener("click", () => {
        if (textarea) {
          const value = textarea.value.trim();
          const minChars = options.textareaMinChars ?? 0;
          if (value.length < minChars) {
            textarea.focus();
            return;
          }
          finish({ action: "primary", text: value });
          return;
        }
        finish({ action: "primary" });
      });
      backdrop.addEventListener("click", (event) => {
        if (event.target === backdrop) {
          finish({ action: "dismiss" });
        }
      });
      footer.appendChild(secondary);
      footer.appendChild(primary);
      modal.appendChild(header);
      modal.appendChild(content);
      modal.appendChild(footer);
      backdrop.appendChild(modal);
      document.documentElement.appendChild(backdrop);
      setTimeout(() => {
        primary.focus();
      }, 0);
    });
  }
  async function showBlockedModal(message, details = []) {
    await createModal({
      title: "Request blocked by policy",
      message,
      details,
      primaryLabel: "Close",
      secondaryLabel: "Edit"
    });
  }
  async function showWarnModal(message, details = []) {
    const result = await createModal({
      title: "Policy warning",
      message,
      details,
      primaryLabel: "Proceed",
      secondaryLabel: "Edit"
    });
    return result.action === "primary";
  }
  async function showRedactModal(message, original, redacted, details = []) {
    const result = await createModal({
      title: "Sensitive content redaction",
      message,
      details,
      primaryLabel: "Apply and Send",
      secondaryLabel: "Edit",
      compareBefore: original,
      compareAfter: redacted
    });
    return result.action === "primary";
  }
  async function showJustificationModal(message, minChars, details = []) {
    const result = await createModal({
      title: "Justification required",
      message,
      details,
      primaryLabel: "Submit",
      secondaryLabel: "Edit",
      textareaLabel: `Justification (${minChars}+ characters)`,
      textareaPlaceholder: "Explain why this prompt should be sent.",
      textareaMinChars: minChars
    });
    if (result.action !== "primary" || !result.text) {
      return { proceed: false };
    }
    return {
      proceed: true,
      justification: result.text
    };
  }

  // src/content/dom/capture.ts
  var EXTENSION_RELOAD_MESSAGE = "UMAI extension updated. Reload this tab to resume monitoring.";
  function sendMessage(message) {
    return new Promise((resolve, reject) => {
      try {
        if (!chrome?.runtime?.id) {
          reject(new Error("Extension context invalidated."));
          return;
        }
        chrome.runtime.sendMessage(message, (response) => {
          const runtimeError = chrome.runtime.lastError;
          if (runtimeError) {
            reject(new Error(runtimeError.message));
            return;
          }
          resolve(response);
        });
      } catch (error) {
        reject(error instanceof Error ? error : new Error("Extension messaging failed."));
      }
    });
  }
  function collectDecisionDetails(decision) {
    const details = [];
    if (decision.rulesFired.length > 0) {
      details.push(`Rules: ${decision.rulesFired.join(", ")}`);
    }
    if (decision.dlpTags.length > 0) {
      details.push(`DLP tags: ${decision.dlpTags.join(", ")}`);
    }
    return details;
  }
  function isExtensionRuntimeUnavailable(error) {
    if (!(error instanceof Error)) {
      return false;
    }
    return error.message.includes("Extension context invalidated") || error.message.includes("Receiving end does not exist") || error.message.includes("message port closed");
  }
  function startCapture(options) {
    const adapter = createSiteAdapter(options.siteId, options.selectors);
    let programmaticSend = false;
    let submitInFlight = false;
    let lastSubmittedAt = 0;
    let lastSubmittedResponse = "";
    let healthSignature = "";
    let observerDisconnect = null;
    let healthIntervalId = null;
    let captureDisabled = false;
    let reloadToastShown = false;
    const disableCapture = () => {
      if (captureDisabled) {
        return;
      }
      captureDisabled = true;
      if (observerDisconnect) {
        observerDisconnect();
        observerDisconnect = null;
      }
      if (healthIntervalId !== null) {
        window.clearInterval(healthIntervalId);
        healthIntervalId = null;
      }
      document.removeEventListener("keydown", onKeyDown, true);
      document.removeEventListener("click", onClick, true);
      if (!reloadToastShown) {
        reloadToastShown = true;
        showToast(EXTENSION_RELOAD_MESSAGE, "warn");
      }
    };
    const evaluateHealth = async () => {
      if (captureDisabled) {
        return;
      }
      const input = adapter.locateInput();
      const root = adapter.locateConversationRoot();
      let status = "ok";
      let details = "selectors healthy";
      if (!input && !root) {
        status = "broken";
        details = "input and conversation root not found";
      } else if (!input || !root) {
        status = "degraded";
        details = !input ? "input selector missing" : "conversation root selector missing";
      }
      const signature = `${status}:${details}`;
      if (signature === healthSignature) {
        return;
      }
      healthSignature = signature;
      await sendMessage({
        type: "ADAPTER_HEALTH",
        payload: {
          site: options.siteId,
          url: window.location.href,
          status,
          details
        }
      }).catch(() => void 0);
    };
    const startResponseObserver = () => {
      if (captureDisabled || observerDisconnect) {
        return;
      }
      const root = adapter.locateConversationRoot();
      if (!root) {
        return;
      }
      observerDisconnect = observeStableAssistantText({
        root,
        stabilityMs: 1400,
        getLatestText: () => {
          const messages = adapter.locateAssistantMessages();
          if (messages.length === 0) {
            return "";
          }
          return messages[messages.length - 1]?.innerText?.trim() ?? "";
        },
        onStable: (text) => {
          if (captureDisabled || !text || text === lastSubmittedResponse) {
            return;
          }
          lastSubmittedResponse = text;
          const latencyMs = lastSubmittedAt > 0 ? Date.now() - lastSubmittedAt : void 0;
          void sendMessage({
            type: "RESPONSE_FINAL",
            payload: {
              site: options.siteId,
              url: window.location.href,
              responseText: text,
              latencyMs
            }
          }).catch(() => void 0);
        }
      });
    };
    const decideAndMaybeSubmit = async (originalPrompt) => {
      if (captureDisabled) {
        return;
      }
      const configResponse = await sendMessage({ type: "GET_CONFIG" });
      const fileInspection = configResponse.config?.config?.fileInspection;
      const attachments = fileInspection ? await getPendingAttachmentManifests(fileInspection) : [];
      const evalResponse = await sendMessage({
        type: "EVAL_PROMPT",
        payload: {
          site: options.siteId,
          url: window.location.href,
          promptText: originalPrompt,
          attachments
        }
      });
      if (!("result" in evalResponse) || !evalResponse.result) {
        showToast("Failed to evaluate policy decision.", "block");
        return;
      }
      const result = evalResponse.result;
      const decision = result.decision;
      const details = collectDecisionDetails(decision);
      const decisionMessage = decision.message ?? "Policy decision returned by UMAI.";
      let proceed = false;
      let finalPrompt = originalPrompt;
      let justification;
      if (decision.type === "allow") {
        proceed = true;
      } else if (decision.type === "warn") {
        proceed = await showWarnModal(decisionMessage, details);
      } else if (decision.type === "justify") {
        const minChars = decision.minJustificationChars ?? 10;
        const resultJustify = await showJustificationModal(decisionMessage, minChars, details);
        proceed = resultJustify.proceed;
        justification = resultJustify.justification;
      } else if (decision.type === "redact") {
        const redacted = decision.redactedText ?? originalPrompt;
        proceed = await showRedactModal(decisionMessage, originalPrompt, redacted, details);
        if (proceed) {
          finalPrompt = redacted;
        }
      } else {
        await showBlockedModal(decisionMessage, details);
        showToast("Prompt blocked by policy.", "block");
        proceed = false;
      }
      if (!proceed) {
        return;
      }
      if (finalPrompt !== originalPrompt) {
        adapter.setPromptText(finalPrompt);
        showToast("Sensitive text redacted before submit.", "warn");
      }
      await sendMessage({
        type: "PROMPT_SUBMITTED",
        payload: {
          site: options.siteId,
          url: window.location.href,
          promptText: finalPrompt,
          justification
        }
      }).catch(() => void 0);
      programmaticSend = true;
      try {
        adapter.submitPrompt();
        lastSubmittedAt = Date.now();
        if (decision.type === "warn" || decision.type === "justify") {
          showToast("Prompt submitted with policy acknowledgment.", "warn");
        }
      } finally {
        setTimeout(() => {
          programmaticSend = false;
        }, 0);
      }
    };
    const handleSubmitInterception = async (event) => {
      if (captureDisabled || programmaticSend || submitInFlight) {
        return;
      }
      const prompt = adapter.getPromptText();
      if (!prompt) {
        return;
      }
      submitInFlight = true;
      event.preventDefault();
      event.stopPropagation();
      if ("stopImmediatePropagation" in event && typeof event.stopImmediatePropagation === "function") {
        event.stopImmediatePropagation();
      }
      try {
        await decideAndMaybeSubmit(prompt);
      } catch (error) {
        if (isExtensionRuntimeUnavailable(error)) {
          disableCapture();
          return;
        }
        showToast("Failed to evaluate policy decision.", "block");
      } finally {
        submitInFlight = false;
      }
    };
    const onKeyDown = (event) => {
      if (!(event instanceof KeyboardEvent)) {
        return;
      }
      if (event.key !== "Enter" || event.shiftKey || event.ctrlKey || event.metaKey || event.altKey) {
        return;
      }
      const input = adapter.locateInput();
      if (!input) {
        return;
      }
      const target = event.target;
      if (!(target instanceof Node) || !input.contains(target) && target !== input) {
        return;
      }
      void handleSubmitInterception(event);
    };
    const onClick = (event) => {
      const sendButton = adapter.locateSendButton();
      if (!sendButton) {
        return;
      }
      const target = event.target;
      if (!(target instanceof Node) || !sendButton.contains(target) && target !== sendButton) {
        return;
      }
      void handleSubmitInterception(event);
    };
    document.addEventListener("keydown", onKeyDown, true);
    document.addEventListener("click", onClick, true);
    startAttachmentCapture();
    startResponseObserver();
    void evaluateHealth();
    healthIntervalId = window.setInterval(() => {
      startResponseObserver();
      void evaluateHealth();
    }, 15e3);
    showToast("UMAI browser governance active.", "ok");
  }

  // src/content/dom/selectors.ts
  var SITE_SELECTORS = {
    chatgpt: {
      input: [
        "#prompt-textarea",
        "textarea[data-testid='chat-input']",
        "textarea"
      ],
      sendButton: [
        "button[data-testid='send-button']",
        "button[aria-label*='Send']",
        "button[type='submit']"
      ],
      conversationRoot: [
        "main",
        "[data-testid='conversation-turns']"
      ],
      assistantMessage: [
        "[data-message-author-role='assistant']",
        "article [data-testid='markdown']",
        "article div.markdown"
      ]
    },
    gemini: {
      input: [
        "textarea",
        "div[contenteditable='true'][role='textbox']",
        "div[contenteditable='true']"
      ],
      sendButton: [
        "button[aria-label*='Send']",
        "button[aria-label*='submit']",
        "button[type='submit']"
      ],
      conversationRoot: [
        "main",
        "body"
      ],
      assistantMessage: [
        "message-content",
        "[data-message-author='model']",
        "div.markdown"
      ]
    },
    claude: {
      input: [
        "div[contenteditable='true'][data-placeholder]",
        "div[contenteditable='true'][role='textbox']",
        "textarea"
      ],
      sendButton: [
        "button[aria-label*='Send']",
        "button[aria-label*='send']",
        "button[type='submit']"
      ],
      conversationRoot: [
        "main",
        "body"
      ],
      assistantMessage: [
        "[data-testid='assistant-message']",
        "[data-message-author='assistant']",
        "div.markdown"
      ]
    }
  };

  // src/content/sites/gemini.ts
  startCapture({
    siteId: "gemini",
    selectors: SITE_SELECTORS.gemini
  });
})();
//# sourceMappingURL=content_gemini.js.map
