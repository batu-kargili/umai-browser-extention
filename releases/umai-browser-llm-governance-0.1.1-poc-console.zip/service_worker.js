// src/background/config.ts
var DEFAULT_ALLOWED_DOMAINS = [
  "chatgpt.com",
  "chat.openai.com",
  "gemini.google.com",
  "claude.ai"
];
var DEFAULT_SHADOW_AI_DOMAINS = [
  "copilot.microsoft.com",
  "perplexity.ai",
  "poe.com",
  "chat.deepseek.com",
  "meta.ai",
  "grok.com"
];
var DEFAULT_FILE_INSPECTION = {
  enabled: true,
  maxFileBytes: 26214400,
  maxExtractedChars: 25e4,
  incompleteAction: "step_up",
  supportedTypes: ["txt", "csv", "xlsx", "docx"]
};
var DEVICE_ID_KEY = "umai_device_id_v1";
var LOCAL_DEV_CONFIG_KEY = "umai_dev_config_v1";
var BOOTSTRAP_STATE_KEY = "umai_bootstrap_state_v1";
var DEFAULT_CONTROL_CENTER_URL = "https://pocttconsole.umaisolutions.com";
var DEFAULT_BOOTSTRAP_TIMEOUT_MS = 15e3;
var ENABLE_BUILTIN_DUMMY_CONFIG = false;
var BUILTIN_DUMMY_CONFIG = {
  tenantId: "00000000-0000-0000-0000-000000000001",
  environment: "stage",
  ingestBaseUrl: "http://localhost:8080/api",
  eventsUrl: "http://localhost:8080/api/v1/ext/events",
  policyUrl: "http://localhost:8080/api/v1/ext/policy",
  evaluateUrl: "http://localhost:8080/api/v1/ext/evaluate",
  evaluationMode: "local",
  bootstrapUrl: "http://localhost:8080/api/v1/ext/bootstrap",
  bootstrapToken: "dummy-bootstrap-token",
  controlCenterUrl: DEFAULT_CONTROL_CENTER_URL,
  captureMode: "metadata_only",
  retentionLocalDays: 7,
  debug: true,
  allowedDomains: DEFAULT_ALLOWED_DOMAINS,
  browserSecurity: {
    enabled: true,
    mode: "enforce",
    shadowAiDomains: DEFAULT_SHADOW_AI_DOMAINS
  }
};
var state = {
  configured: false,
  issues: ["Configuration not loaded yet."]
};
var initialized = false;
function isNonEmptyString(value) {
  return typeof value === "string" && value.trim().length > 0;
}
function isUuid(value) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
    value
  );
}
function normalizeStringArray(value, fallback) {
  if (!Array.isArray(value)) {
    return [...fallback];
  }
  const next = value.filter((entry) => isNonEmptyString(entry)).map((entry) => entry.trim().toLowerCase());
  return next.length > 0 ? next : [...fallback];
}
function getDefaultBrowserSecurity() {
  return {
    enabled: false,
    mode: "enforce",
    shadowAiDomains: [...DEFAULT_SHADOW_AI_DOMAINS]
  };
}
function normalizeBrowserSecurity(raw) {
  const defaults = getDefaultBrowserSecurity();
  return {
    enabled: raw?.enabled === true,
    mode: raw?.mode === "audit" ? "audit" : defaults.mode,
    shadowAiDomains: normalizeStringArray(raw?.shadowAiDomains, defaults.shadowAiDomains)
  };
}
function normalizeFileInspection(raw) {
  const supportedTypes = normalizeStringArray(raw?.supportedTypes, DEFAULT_FILE_INSPECTION.supportedTypes).map((entry) => entry.replace(/^\./, "")).filter((entry) => entry.length > 0);
  const incompleteAction = raw?.incompleteAction === "block" || raw?.incompleteAction === "warn" ? raw.incompleteAction : DEFAULT_FILE_INSPECTION.incompleteAction;
  return {
    enabled: raw?.enabled !== false,
    maxFileBytes: typeof raw?.maxFileBytes === "number" && raw.maxFileBytes > 0 ? Math.floor(raw.maxFileBytes) : DEFAULT_FILE_INSPECTION.maxFileBytes,
    maxExtractedChars: typeof raw?.maxExtractedChars === "number" && raw.maxExtractedChars > 0 ? Math.floor(raw.maxExtractedChars) : DEFAULT_FILE_INSPECTION.maxExtractedChars,
    incompleteAction,
    supportedTypes: supportedTypes.length > 0 ? supportedTypes : [...DEFAULT_FILE_INSPECTION.supportedTypes]
  };
}
function displayNameFromEmail(email) {
  const localPart = email.split("@")[0]?.trim();
  if (!localPart) {
    return void 0;
  }
  const words = localPart.replace(/[._-]+/g, " ").split(/\s+/).filter(Boolean);
  if (words.length === 0) {
    return void 0;
  }
  return words.map((word) => `${word.charAt(0).toUpperCase()}${word.slice(1)}`).join(" ");
}
function storageLocalGet(key) {
  return new Promise((resolve) => {
    chrome.storage.local.get([key], (result) => {
      resolve(result[key]);
    });
  });
}
function storageLocalSet(values) {
  return new Promise((resolve) => {
    chrome.storage.local.set(values, () => resolve());
  });
}
function storageLocalRemove(key) {
  return new Promise((resolve) => {
    chrome.storage.local.remove([key], () => resolve());
  });
}
function storageManagedGetAll() {
  return new Promise((resolve) => {
    try {
      chrome.storage.managed.get(null, (result) => {
        if (chrome.runtime.lastError) {
          resolve({});
          return;
        }
        resolve(result ?? {});
      });
    } catch (_error) {
      resolve({});
    }
  });
}
async function getBrowserProfileIdentity() {
  try {
    if (!chrome.identity?.getProfileUserInfo) {
      return {};
    }
    const profile = await chrome.identity.getProfileUserInfo({ accountStatus: "ANY" });
    const email = isNonEmptyString(profile.email) ? profile.email.trim() : void 0;
    const id = isNonEmptyString(profile.id) ? profile.id.trim() : void 0;
    return {
      email,
      id,
      displayName: email ? displayNameFromEmail(email) : void 0
    };
  } catch (_error) {
    return {};
  }
}
async function resolveDeviceId(preferred) {
  if (isNonEmptyString(preferred)) {
    return preferred.trim();
  }
  const existing = await storageLocalGet(DEVICE_ID_KEY);
  if (isNonEmptyString(existing)) {
    return existing;
  }
  const next = crypto.randomUUID();
  await storageLocalSet({ [DEVICE_ID_KEY]: next });
  return next;
}
async function clearBootstrapState() {
  await storageLocalRemove(BOOTSTRAP_STATE_KEY);
}
function buildBootstrapCacheKey(raw, tenantId, deviceId) {
  const bootstrapUrl = isNonEmptyString(raw.bootstrapUrl) ? raw.bootstrapUrl.trim() : "";
  const bootstrapToken = isNonEmptyString(raw.bootstrapToken) ? raw.bootstrapToken.trim() : "";
  return `${tenantId}|${deviceId}|${bootstrapUrl}|${bootstrapToken}`;
}
function isBootstrapResponse(value) {
  if (!value || typeof value !== "object") {
    return false;
  }
  const casted = value;
  return isNonEmptyString(casted.tenant_id) && isNonEmptyString(casted.device_id) && isNonEmptyString(casted.device_token) && typeof casted.expires_at === "number";
}
async function fetchBootstrapDeviceToken(raw, tenantId, deviceId) {
  const bootstrapUrl = isNonEmptyString(raw.bootstrapUrl) ? raw.bootstrapUrl.trim() : "";
  const bootstrapToken = isNonEmptyString(raw.bootstrapToken) ? raw.bootstrapToken.trim() : "";
  if (!bootstrapUrl || !bootstrapToken) {
    return "";
  }
  const cacheKey = buildBootstrapCacheKey(raw, tenantId, deviceId);
  const cached = await storageLocalGet(BOOTSTRAP_STATE_KEY);
  const now = Math.floor(Date.now() / 1e3);
  if (cached && cached.cacheKey === cacheKey && isNonEmptyString(cached.deviceToken) && typeof cached.expiresAt === "number" && cached.expiresAt > now + 60) {
    return cached.deviceToken;
  }
  const response = await fetch(bootstrapUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${bootstrapToken}`,
      "X-Tenant-Id": tenantId
    },
    body: JSON.stringify({
      tenant_id: tenantId,
      device_id: deviceId,
      extension_id: chrome.runtime.id
    }),
    cache: "no-store",
    credentials: "omit"
  });
  if (!response.ok) {
    let reason = `Bootstrap failed (${response.status}).`;
    try {
      const errorBody = await response.json();
      reason = errorBody.error || errorBody.message || reason;
    } catch (_error) {
    }
    throw new Error(reason);
  }
  const body = await response.json();
  if (!isBootstrapResponse(body)) {
    throw new Error("Bootstrap response is invalid.");
  }
  await storageLocalSet({
    [BOOTSTRAP_STATE_KEY]: {
      cacheKey,
      deviceToken: body.device_token,
      expiresAt: body.expires_at
    }
  });
  return body.device_token;
}
async function resolveDeviceToken(raw, tenantId, deviceId) {
  const explicit = isNonEmptyString(raw.deviceToken) ? raw.deviceToken.trim() : "";
  if (explicit) {
    return explicit;
  }
  return fetchBootstrapDeviceToken(raw, tenantId, deviceId);
}
async function validateManagedConfig(raw) {
  const issues = [];
  const tenantId = isNonEmptyString(raw.tenantId) ? raw.tenantId.trim() : "";
  const environment = raw.environment === "prod" || raw.environment === "stage" ? raw.environment : void 0;
  const ingestBaseUrl = isNonEmptyString(raw.ingestBaseUrl) ? raw.ingestBaseUrl.trim() : "";
  const eventsUrl = isNonEmptyString(raw.eventsUrl) ? raw.eventsUrl.trim() : "";
  const policyUrl = isNonEmptyString(raw.policyUrl) ? raw.policyUrl.trim() : "";
  const evaluateUrl = isNonEmptyString(raw.evaluateUrl) ? raw.evaluateUrl.trim() : "";
  const evaluationMode = raw.evaluationMode === "server" ? "server" : "local";
  const bootstrapUrl = isNonEmptyString(raw.bootstrapUrl) ? raw.bootstrapUrl.trim() : "";
  const bootstrapToken = isNonEmptyString(raw.bootstrapToken) ? raw.bootstrapToken.trim() : "";
  const controlCenterUrl = isNonEmptyString(raw.controlCenterUrl) ? raw.controlCenterUrl.trim() : DEFAULT_CONTROL_CENTER_URL;
  const profileIdentity = await getBrowserProfileIdentity();
  const userEmail = isNonEmptyString(raw.userEmail) ? raw.userEmail.trim() : profileIdentity.email;
  const userIdpSubject = isNonEmptyString(raw.userIdpSubject) ? raw.userIdpSubject.trim() : profileIdentity.id;
  const userDisplayName = isNonEmptyString(raw.userDisplayName) ? raw.userDisplayName.trim() : profileIdentity.displayName;
  const captureMode = raw.captureMode === "full_content" ? "full_content" : "metadata_only";
  const retentionLocalDays = typeof raw.retentionLocalDays === "number" && raw.retentionLocalDays > 0 ? raw.retentionLocalDays : 7;
  const debug = raw.debug === true;
  const allowedDomains = normalizeStringArray(raw.allowedDomains, DEFAULT_ALLOWED_DOMAINS);
  const browserSecurity = normalizeBrowserSecurity(raw.browserSecurity);
  const fileInspection = normalizeFileInspection(raw.fileInspection);
  const breakGlass = raw.breakGlass;
  if (!tenantId) {
    issues.push("tenantId is required.");
  } else if (!isUuid(tenantId)) {
    issues.push("tenantId must be a UUID.");
  }
  if (!environment) {
    issues.push("environment must be prod or stage.");
  }
  if (!ingestBaseUrl) {
    issues.push("ingestBaseUrl is required.");
  }
  if (eventsUrl) {
    try {
      new URL(eventsUrl);
    } catch (_error) {
      issues.push("eventsUrl must be a valid URL.");
    }
  }
  if (!policyUrl) {
    issues.push("policyUrl is required.");
  }
  if (evaluationMode === "server") {
    if (!evaluateUrl) {
      issues.push("evaluateUrl is required when evaluationMode is server.");
    } else {
      try {
        new URL(evaluateUrl);
      } catch (_error) {
        issues.push("evaluateUrl must be a valid URL.");
      }
    }
  }
  if (bootstrapUrl || bootstrapToken) {
    if (!bootstrapUrl || !bootstrapToken) {
      issues.push("bootstrapUrl and bootstrapToken are required together.");
    } else {
      try {
        new URL(bootstrapUrl);
      } catch (_error) {
        issues.push("bootstrapUrl must be a valid URL.");
      }
    }
  }
  try {
    new URL(controlCenterUrl);
  } catch (_error) {
    issues.push("controlCenterUrl must be a valid URL.");
  }
  const deviceId = await resolveDeviceId(raw.deviceId);
  let deviceToken = "";
  if (issues.length === 0) {
    try {
      deviceToken = await Promise.race([
        resolveDeviceToken(raw, tenantId, deviceId),
        new Promise((_, reject) => {
          setTimeout(() => reject(new Error("Bootstrap timed out.")), DEFAULT_BOOTSTRAP_TIMEOUT_MS);
        })
      ]);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to bootstrap extension device token.";
      issues.push(message);
    }
  }
  if (!deviceToken) {
    issues.push("deviceToken or bootstrapUrl/bootstrapToken is required.");
  }
  if (issues.length > 0) {
    return { configured: false, issues };
  }
  const config = {
    tenantId,
    environment,
    ingestBaseUrl,
    eventsUrl: eventsUrl || void 0,
    policyUrl,
    evaluateUrl: evaluateUrl || void 0,
    evaluationMode,
    controlCenterUrl,
    userEmail,
    userIdpSubject,
    userDisplayName,
    deviceToken,
    deviceId,
    captureMode,
    retentionLocalDays,
    debug,
    allowedDomains,
    browserSecurity,
    fileInspection,
    breakGlass
  };
  return {
    configured: true,
    issues: [],
    config
  };
}
async function refreshRuntimeConfig() {
  const managed = await storageManagedGetAll();
  const managedState = await validateManagedConfig(managed);
  if (managedState.configured) {
    state = managedState;
    return state;
  }
  const localFallback = await storageLocalGet(LOCAL_DEV_CONFIG_KEY);
  if (localFallback) {
    const localState = await validateManagedConfig(localFallback);
    if (localState.configured) {
      state = {
        ...localState,
        issues: ["Using local dev fallback config from chrome.storage.local."]
      };
      return state;
    }
  }
  if (ENABLE_BUILTIN_DUMMY_CONFIG) {
    const dummyState = await validateManagedConfig(BUILTIN_DUMMY_CONFIG);
    if (dummyState.configured) {
      state = {
        ...dummyState,
        issues: ["Using built-in dummy config. Replace with managed policy for production."]
      };
      return state;
    }
  }
  state = managedState;
  return state;
}
function getRuntimeState() {
  return state;
}
function getBrowserSecurityConfig() {
  return state.configured && state.config ? state.config.browserSecurity : getDefaultBrowserSecurity();
}
function isUrlAllowed(url) {
  const urlObj = new URL(url);
  const hostname = urlObj.hostname.toLowerCase();
  const allowedDomains = state.configured ? state.config?.allowedDomains ?? DEFAULT_ALLOWED_DOMAINS : DEFAULT_ALLOWED_DOMAINS;
  return allowedDomains.some(
    (domain) => hostname === domain || hostname.endsWith(`.${domain}`)
  );
}
async function initConfigModule() {
  if (!initialized) {
    initialized = true;
    chrome.storage.onChanged.addListener((changes, areaName) => {
      const managedChanged = areaName === "managed" && (changes.tenantId || changes.environment || changes.policyUrl || changes.eventsUrl || changes.evaluateUrl || changes.evaluationMode || changes.bootstrapUrl || changes.bootstrapToken || changes.controlCenterUrl || changes.userEmail || changes.userIdpSubject || changes.userDisplayName || changes.ingestBaseUrl || changes.deviceToken || changes.deviceId || changes.captureMode || changes.retentionLocalDays || changes.debug || changes.allowedDomains || changes.browserSecurity || changes.fileInspection || changes.breakGlass);
      const localFallbackChanged = areaName === "local" && changes[LOCAL_DEV_CONFIG_KEY];
      if (managedChanged || localFallbackChanged) {
        void refreshRuntimeConfig();
      }
    });
  }
  return refreshRuntimeConfig();
}
async function setLocalDevConfig(raw) {
  await clearBootstrapState();
  await storageLocalSet({ [LOCAL_DEV_CONFIG_KEY]: raw });
  return refreshRuntimeConfig();
}
async function clearLocalDevConfig() {
  await clearBootstrapState();
  await storageLocalRemove(LOCAL_DEV_CONFIG_KEY);
  return refreshRuntimeConfig();
}

// src/background/auth.ts
function buildAuthHeaders(config) {
  return {
    Authorization: `Bearer ${config.deviceToken}`,
    "X-Tenant-Id": config.tenantId,
    "X-Device-Id": config.deviceId
  };
}

// src/shared/hash.ts
function isPlainObject(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function canonicalize(value) {
  if (Array.isArray(value)) {
    return value.map((item) => canonicalize(item));
  }
  if (isPlainObject(value)) {
    const keys = Object.keys(value).sort();
    const out = {};
    for (const key of keys) {
      out[key] = canonicalize(value[key]);
    }
    return out;
  }
  return value;
}
function stableJsonStringify(value) {
  return JSON.stringify(canonicalize(value));
}
async function sha256Hex(input) {
  const bytes = new TextEncoder().encode(input);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  const view = new Uint8Array(digest);
  return Array.from(view, (value) => value.toString(16).padStart(2, "0")).join("");
}
async function hashObjectHex(value) {
  return sha256Hex(stableJsonStringify(value));
}

// src/background/events.ts
var LAST_EVENT_HASH_KEY = "umai_last_event_hash_v1";
function storageLocalGet2(key) {
  return new Promise((resolve) => {
    chrome.storage.local.get([key], (result) => resolve(result[key]));
  });
}
function storageLocalSet2(values) {
  return new Promise((resolve) => {
    chrome.storage.local.set(values, () => resolve());
  });
}
function storageLocalRemove2(key) {
  return new Promise((resolve) => {
    chrome.storage.local.remove([key], () => resolve());
  });
}
function clonePayload(payload) {
  return JSON.parse(JSON.stringify(payload));
}
async function applyCaptureMode(payload, captureMode, textFields) {
  const next = clonePayload(payload);
  for (const key of textFields) {
    const value = next[key];
    if (typeof value !== "string") {
      continue;
    }
    if (captureMode === "full_content") {
      continue;
    }
    next[`${key}_len`] = value.length;
    next[`${key}_hash`] = await hashObjectHex({ text: value });
    delete next[key];
  }
  return next;
}
async function buildEventEnvelope(input) {
  const prevHash = await storageLocalGet2(LAST_EVENT_HASH_KEY) ?? null;
  const eventId = crypto.randomUUID();
  const effectiveUserEmail = input.userEmail ?? input.config.userEmail;
  const effectiveUserIdpSubject = input.userIdpSubject ?? input.config.userIdpSubject;
  const effectiveUserDisplayName = input.userDisplayName ?? input.config.userDisplayName;
  const payload = clonePayload(input.payload);
  if (effectiveUserDisplayName && !payload.user_name) {
    payload.user_name = effectiveUserDisplayName;
  }
  const provisional = {
    event_id: eventId,
    event_type: input.eventType,
    tenant_id: input.config.tenantId,
    user: {
      user_email: effectiveUserEmail,
      user_idp_subject: effectiveUserIdpSubject
    },
    device: {
      device_id: input.config.deviceId
    },
    app: {
      site: input.site,
      url: input.url,
      tab_id: input.tabId
    },
    timestamps: {
      captured_at_ms: Date.now()
    },
    chain: {
      prev_event_hash: prevHash,
      event_hash: ""
    },
    payload
  };
  const eventHash = await hashObjectHex(provisional);
  const event = {
    ...provisional,
    chain: {
      prev_event_hash: prevHash,
      event_hash: eventHash
    }
  };
  await storageLocalSet2({ [LAST_EVENT_HASH_KEY]: eventHash });
  return event;
}
async function resetEventChain() {
  await storageLocalRemove2(LAST_EVENT_HASH_KEY);
}

// src/background/queue.ts
var QUEUE_KEY = "umai_event_queue_v1";
function storageLocalGet3(key) {
  return new Promise((resolve) => {
    chrome.storage.local.get([key], (result) => resolve(result[key]));
  });
}
function storageLocalSet3(values) {
  return new Promise((resolve) => {
    chrome.storage.local.set(values, () => resolve());
  });
}
function storageLocalRemove3(key) {
  return new Promise((resolve) => {
    chrome.storage.local.remove([key], () => resolve());
  });
}
var queueLock = Promise.resolve();
async function withLock(fn) {
  const previous = queueLock;
  let release = () => void 0;
  queueLock = new Promise((resolve) => {
    release = resolve;
  });
  await previous;
  try {
    return await fn();
  } finally {
    release();
  }
}
async function readQueue() {
  const existing = await storageLocalGet3(QUEUE_KEY);
  if (!Array.isArray(existing)) {
    return [];
  }
  return existing;
}
async function writeQueue(next) {
  await storageLocalSet3({ [QUEUE_KEY]: next });
}
async function enqueueEvent(event) {
  await withLock(async () => {
    const queue = await readQueue();
    queue.push({
      createdAtMs: Date.now(),
      attemptCount: 0,
      event
    });
    await writeQueue(queue);
  });
}
async function markAttempted(eventIds) {
  if (eventIds.length === 0) {
    return;
  }
  await withLock(async () => {
    const queue = await readQueue();
    const idSet = new Set(eventIds);
    const next = queue.map(
      (item) => idSet.has(item.event.event_id) ? {
        ...item,
        attemptCount: item.attemptCount + 1
      } : item
    );
    await writeQueue(next);
  });
}
async function ackEvents(eventIds) {
  if (eventIds.length === 0) {
    return;
  }
  await withLock(async () => {
    const idSet = new Set(eventIds);
    const queue = await readQueue();
    const next = queue.filter((item) => !idSet.has(item.event.event_id));
    await writeQueue(next);
  });
}
async function takeBatch(limit = 25) {
  return withLock(async () => {
    const queue = await readQueue();
    return queue.slice(0, limit);
  });
}
async function compactQueue(retentionDays) {
  const cutoff = Date.now() - retentionDays * 24 * 60 * 60 * 1e3;
  await withLock(async () => {
    const queue = await readQueue();
    const next = queue.filter((item) => item.createdAtMs >= cutoff);
    if (next.length !== queue.length) {
      await writeQueue(next);
    }
  });
}
async function clearQueue() {
  await withLock(async () => {
    await storageLocalRemove3(QUEUE_KEY);
  });
}

// src/background/browser_security.ts
var BLOCKED_PAGE_PATH = "blocked.html";
var handledNavigationByTab = /* @__PURE__ */ new Map();
var initialized2 = false;
function safeParseUrl(url) {
  try {
    return new URL(url);
  } catch (_error) {
    return null;
  }
}
function matchesDomain(hostname, domain) {
  return hostname === domain || hostname.endsWith(`.${domain}`);
}
function isBlockedPageUrl(url) {
  return url.startsWith(chrome.runtime.getURL(BLOCKED_PAGE_PATH));
}
function evaluateBrowserSecurity(url) {
  if (isBlockedPageUrl(url)) {
    return null;
  }
  const parsedUrl = safeParseUrl(url);
  if (!parsedUrl || parsedUrl.protocol !== "http:" && parsedUrl.protocol !== "https:") {
    return null;
  }
  const runtimeState = getRuntimeState();
  const allowedDomains = runtimeState.configured && runtimeState.config ? runtimeState.config.allowedDomains : [];
  const hostname = parsedUrl.hostname.toLowerCase();
  if (allowedDomains.some((domain) => matchesDomain(hostname, domain))) {
    return null;
  }
  const browserSecurity = getBrowserSecurityConfig();
  if (!browserSecurity.enabled) {
    return null;
  }
  const matchedDomain = browserSecurity.shadowAiDomains.find((domain) => matchesDomain(hostname, domain));
  if (!matchedDomain) {
    return null;
  }
  if (!runtimeState.configured || !runtimeState.config) {
    return {
      action: "block",
      allowedDomains: [],
      blockedUrl: url,
      configured: false,
      hostname,
      matchedDomain,
      message: "UMAI browser guardrails are not connected. Known AI sites stay blocked until the organization is connected.",
      mode: "enforce"
    };
  }
  if (browserSecurity.mode === "audit") {
    return {
      action: "audit",
      allowedDomains,
      blockedUrl: url,
      configured: true,
      hostname,
      matchedDomain,
      message: "Known AI site detected outside the approved UMAI allowlist.",
      mode: "audit"
    };
  }
  return {
    action: "block",
    allowedDomains,
    blockedUrl: url,
    configured: true,
    hostname,
    matchedDomain,
    message: "This AI site is not approved by your organization. Use an approved assistant instead.",
    mode: "enforce"
  };
}
function buildBlockedPageUrl(decision) {
  const next = new URL(chrome.runtime.getURL(BLOCKED_PAGE_PATH));
  next.searchParams.set("blocked", decision.blockedUrl);
  next.searchParams.set("host", decision.hostname);
  next.searchParams.set("mode", decision.configured ? decision.mode : "fail-closed");
  next.searchParams.set("reason", decision.message);
  if (decision.allowedDomains.length > 0) {
    next.searchParams.set("approved", decision.allowedDomains.join(","));
  }
  return next.toString();
}
function queryTabs() {
  return new Promise((resolve) => {
    chrome.tabs.query({}, (tabs) => {
      resolve(Array.isArray(tabs) ? tabs : []);
    });
  });
}
function updateTab(tabId, url) {
  return new Promise((resolve) => {
    chrome.tabs.update(tabId, { url }, () => {
      resolve(!chrome.runtime.lastError);
    });
  });
}
async function logBrowserSecurityDecision(tabId, decision) {
  const runtimeState = getRuntimeState();
  if (!runtimeState.configured || !runtimeState.config) {
    return;
  }
  const event = await buildEventEnvelope({
    config: runtimeState.config,
    eventType: "shadow_ai_navigation",
    site: "extension",
    url: decision.blockedUrl,
    tabId,
    payload: {
      action: decision.action,
      allowed_domains: decision.allowedDomains,
      blocked_host: decision.hostname,
      blocked_url: decision.blockedUrl,
      configured: decision.configured,
      guard_mode: decision.mode,
      matched_domain: decision.matchedDomain,
      reason: decision.message
    }
  });
  await enqueueEvent(event);
}
async function handleBrowserSecurityForTab(tabId, url) {
  if (isBlockedPageUrl(url)) {
    handledNavigationByTab.delete(tabId);
    return;
  }
  const decision = evaluateBrowserSecurity(url);
  if (!decision) {
    handledNavigationByTab.delete(tabId);
    return;
  }
  if (handledNavigationByTab.get(tabId) === url) {
    return;
  }
  handledNavigationByTab.set(tabId, url);
  await logBrowserSecurityDecision(tabId, decision);
  if (decision.action !== "block") {
    return;
  }
  const redirected = await updateTab(tabId, buildBlockedPageUrl(decision));
  if (!redirected) {
    handledNavigationByTab.delete(tabId);
  }
}
function initBrowserSecurityGuardrails() {
  if (initialized2) {
    return;
  }
  initialized2 = true;
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    const nextUrl = typeof changeInfo.url === "string" ? changeInfo.url : tab.pendingUrl ?? tab.url;
    if (!nextUrl) {
      return;
    }
    void handleBrowserSecurityForTab(tabId, nextUrl);
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    handledNavigationByTab.delete(tabId);
  });
}
async function enforceBrowserSecurityAcrossTabs() {
  const tabs = await queryTabs();
  await Promise.all(
    tabs.map((tab) => {
      if (typeof tab.id !== "number") {
        return Promise.resolve();
      }
      const url = tab.pendingUrl ?? tab.url;
      if (!url) {
        return Promise.resolve();
      }
      return handleBrowserSecurityForTab(tab.id, url);
    })
  );
}

// src/shared/redact.ts
function findingsToRedactionSpans(findings) {
  const sorted = [...findings].map((finding) => ({ start: finding.start, end: finding.end, kind: finding.type })).sort((a, b) => a.start - b.start || a.end - b.end);
  const merged = [];
  for (const span of sorted) {
    const last = merged[merged.length - 1];
    if (!last || span.start > last.end) {
      merged.push(span);
      continue;
    }
    if (span.end > last.end) {
      last.end = span.end;
    }
    if (!last.kind.includes(span.kind)) {
      last.kind = `${last.kind}|${span.kind}`;
    }
  }
  return merged;
}
function applyRedactionsToText(original, redactions, strategy = "mask") {
  if (redactions.length === 0) {
    return original;
  }
  const sorted = [...redactions].sort((a, b) => b.start - a.start);
  let next = original;
  for (const redaction of sorted) {
    const replacement = strategy === "token" ? "[REDACTED]" : `[REDACTED:${redaction.kind.split("|")[0] ?? "SENSITIVE"}]`;
    next = `${next.slice(0, redaction.start)}${replacement}${next.slice(redaction.end)}`;
  }
  return next;
}

// src/shared/policy_engine.ts
var DEFAULT_POLICY_PACK = {
  version: "default-local-allow",
  default_action: "allow",
  rules: []
};
function getDefaultPolicyPack() {
  return DEFAULT_POLICY_PACK;
}
function matchesRule(rule, dlp) {
  const requiredTags = rule.match.dlp_tags_any;
  if (requiredTags && requiredTags.length > 0) {
    return requiredTags.some((tag) => dlp.tags.includes(tag));
  }
  return false;
}
function defaultDecision(dlp, action) {
  return {
    type: action,
    message: void 0,
    rulesFired: [],
    dlpTags: dlp.tags,
    redactions: [],
    requireJustification: action === "justify",
    minJustificationChars: action === "justify" ? 10 : void 0
  };
}
function evaluatePromptPolicy(promptText, dlp, policyPack2) {
  const policy = policyPack2 ?? DEFAULT_POLICY_PACK;
  for (const rule of policy.rules) {
    if (!rule.enabled || !matchesRule(rule, dlp)) {
      continue;
    }
    const base = {
      type: rule.action.type,
      message: rule.message,
      rulesFired: [rule.id],
      dlpTags: dlp.tags,
      redactions: [],
      requireJustification: rule.action.type === "justify",
      minJustificationChars: rule.action.min_chars
    };
    if (rule.action.type === "redact") {
      const redactions = findingsToRedactionSpans(dlp.findings);
      return {
        ...base,
        redactions,
        redactedText: applyRedactionsToText(promptText, redactions, rule.action.strategy ?? "mask")
      };
    }
    return base;
  }
  return defaultDecision(dlp, policy.default_action);
}

// src/background/policy_cache.ts
var POLICY_CACHE_KEY = "umai_policy_cache_v1";
var POLICY_ETAG_KEY = "umai_policy_etag_v1";
var POLICY_FETCHED_AT_KEY = "umai_policy_fetched_at_ms_v1";
var policyPack = getDefaultPolicyPack();
function storageLocalGet4(key) {
  return new Promise((resolve) => {
    chrome.storage.local.get([key], (result) => {
      resolve(result[key]);
    });
  });
}
function storageLocalSet4(values) {
  return new Promise((resolve) => {
    chrome.storage.local.set(values, () => resolve());
  });
}
function isPolicyPack(value) {
  if (!value || typeof value !== "object") {
    return false;
  }
  const casted = value;
  return typeof casted.version === "string" && typeof casted.default_action === "string" && Array.isArray(casted.rules);
}
async function initPolicyCache() {
  const cached = await storageLocalGet4(POLICY_CACHE_KEY);
  if (cached && isPolicyPack(cached)) {
    policyPack = cached;
  }
}
function getPolicyPack() {
  return policyPack;
}
async function refreshPolicyPack() {
  const runtimeState = getRuntimeState();
  if (!runtimeState.configured || !runtimeState.config) {
    return policyPack;
  }
  const policyUrl = runtimeState.config.policyUrl;
  const etag = await storageLocalGet4(POLICY_ETAG_KEY);
  const headers = {
    Authorization: `Bearer ${runtimeState.config.deviceToken}`,
    "X-Tenant-Id": runtimeState.config.tenantId
  };
  if (etag) {
    headers["If-None-Match"] = etag;
  }
  try {
    const response = await fetch(policyUrl, {
      method: "GET",
      headers
    });
    if (response.status === 304) {
      return policyPack;
    }
    if (!response.ok) {
      return policyPack;
    }
    const next = await response.json();
    if (!isPolicyPack(next)) {
      return policyPack;
    }
    policyPack = next;
    await storageLocalSet4({
      [POLICY_CACHE_KEY]: next,
      [POLICY_ETAG_KEY]: response.headers.get("ETag") ?? "",
      [POLICY_FETCHED_AT_KEY]: Date.now()
    });
  } catch (_error) {
  }
  return policyPack;
}

// src/background/uploader.ts
var started = false;
var isFlushing = false;
var backoffMs = 2e3;
function computeEndpoint(baseUrl) {
  const trimmed = baseUrl.replace(/\/+$/, "");
  if (trimmed.endsWith("/ext/events")) {
    return trimmed;
  }
  if (trimmed.endsWith("/api/public") || trimmed.endsWith("/api/v1")) {
    return `${trimmed}/ext/events`;
  }
  return `${trimmed}/v1/ext/events`;
}
function scheduleNext() {
  const jitter = Math.floor(Math.random() * 350);
  setTimeout(() => {
    void flushQueue();
  }, backoffMs + jitter);
}
async function flushQueue() {
  if (isFlushing) {
    return;
  }
  isFlushing = true;
  try {
    const runtimeState = getRuntimeState();
    if (!runtimeState.configured || !runtimeState.config) {
      backoffMs = Math.min(backoffMs * 2, 6e4);
      return;
    }
    const config = runtimeState.config;
    await compactQueue(config.retentionLocalDays);
    const batch = await takeBatch(25);
    if (batch.length === 0) {
      backoffMs = 5e3;
      return;
    }
    const eventIds = batch.map((item) => item.event.event_id);
    await markAttempted(eventIds);
    const response = await fetch(config.eventsUrl ?? computeEndpoint(config.ingestBaseUrl), {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...buildAuthHeaders(config)
      },
      body: JSON.stringify({
        tenant_id: config.tenantId,
        device_id: config.deviceId,
        events: batch.map((item) => item.event)
      })
    });
    if (!response.ok) {
      if (response.status === 422) {
        await ackEvents(eventIds);
        backoffMs = 2e3;
        return;
      }
      backoffMs = Math.min(backoffMs * 2, 6e4);
      return;
    }
    await ackEvents(eventIds);
    backoffMs = 2e3;
  } catch (_error) {
    backoffMs = Math.min(backoffMs * 2, 6e4);
  } finally {
    isFlushing = false;
    scheduleNext();
  }
}
function startUploader() {
  if (started) {
    return;
  }
  started = true;
  scheduleNext();
}

// src/shared/dlp.ts
var SECRET_PATTERNS = [
  {
    tag: "SECRET_BEARER_TOKEN",
    regex: /\bBearer\s+[A-Za-z0-9\-._~+/]+=*/g,
    confidence: 0.95,
    weight: 8
  },
  {
    tag: "SECRET_PRIVATE_KEY",
    regex: /-----BEGIN\s+(?:RSA|EC|OPENSSH|PGP)?\s*PRIVATE KEY-----[\s\S]+?-----END\s+(?:RSA|EC|OPENSSH|PGP)?\s*PRIVATE KEY-----/g,
    confidence: 0.99,
    weight: 10
  },
  {
    tag: "SECRET_TOKEN",
    regex: /\b(?:sk|api|token)_[A-Za-z0-9]{16,}\b/g,
    confidence: 0.85,
    weight: 7
  }
];
var PII_PATTERNS = [
  {
    tag: "PII_EMAIL",
    regex: /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g,
    confidence: 0.9,
    weight: 3
  },
  {
    tag: "PII_PHONE",
    regex: /\b(?:\+?\d{1,3}[\s.-]?)?(?:\(?\d{2,4}\)?[\s.-]?)?\d{3,4}[\s.-]?\d{3,4}\b/g,
    confidence: 0.75,
    weight: 2
  }
];
var CREDIT_CARD_REGEX = /\b(?:\d[ -]*?){13,19}\b/g;
var IBAN_REGEX = /\b[A-Z]{2}\d{2}[A-Z0-9]{11,30}\b/g;
function luhnValid(raw) {
  const digits = raw.replace(/[^\d]/g, "");
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  let sum = 0;
  let shouldDouble = false;
  for (let idx = digits.length - 1; idx >= 0; idx -= 1) {
    let digit = Number(digits[idx]);
    if (Number.isNaN(digit)) {
      return false;
    }
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  return sum % 10 === 0;
}
function ibanValid(raw) {
  const compact = raw.replace(/\s+/g, "").toUpperCase();
  if (!/^[A-Z]{2}\d{2}[A-Z0-9]+$/.test(compact)) {
    return false;
  }
  const moved = `${compact.slice(4)}${compact.slice(0, 4)}`;
  let expanded = "";
  for (const ch of moved) {
    if (/[A-Z]/.test(ch)) {
      expanded += String(ch.charCodeAt(0) - 55);
    } else {
      expanded += ch;
    }
  }
  let remainder = 0;
  for (const digit of expanded) {
    remainder = (remainder * 10 + Number(digit)) % 97;
  }
  return remainder === 1;
}
function addFinding(findings, tagSet, data) {
  findings.push({
    type: data.tag,
    start: data.start,
    end: data.end,
    confidence: data.confidence,
    sample: data.sample
  });
  tagSet.add(data.tag);
}
function collectPatternFindings(text, definitions, findings, tagSet) {
  let risk = 0;
  for (const definition of definitions) {
    definition.regex.lastIndex = 0;
    let match;
    while ((match = definition.regex.exec(text)) !== null) {
      addFinding(findings, tagSet, {
        tag: definition.tag,
        start: match.index,
        end: match.index + match[0].length,
        confidence: definition.confidence,
        sample: match[0].slice(0, 64)
      });
      risk += definition.weight;
    }
  }
  return risk;
}
function scanTextForDlp(text) {
  const findings = [];
  const tags = /* @__PURE__ */ new Set();
  let riskScore = 0;
  riskScore += collectPatternFindings(text, SECRET_PATTERNS, findings, tags);
  riskScore += collectPatternFindings(text, PII_PATTERNS, findings, tags);
  CREDIT_CARD_REGEX.lastIndex = 0;
  let cardMatch;
  while ((cardMatch = CREDIT_CARD_REGEX.exec(text)) !== null) {
    const value = cardMatch[0];
    if (!luhnValid(value)) {
      continue;
    }
    addFinding(findings, tags, {
      tag: "PII_CREDITCARD",
      start: cardMatch.index,
      end: cardMatch.index + value.length,
      confidence: 0.9,
      sample: value.slice(0, 32)
    });
    riskScore += 6;
  }
  IBAN_REGEX.lastIndex = 0;
  let ibanMatch;
  while ((ibanMatch = IBAN_REGEX.exec(text)) !== null) {
    const value = ibanMatch[0];
    if (!ibanValid(value)) {
      continue;
    }
    const ibanTag = value.startsWith("TR") ? "PII_IBAN_TR" : "PII_IBAN";
    addFinding(findings, tags, {
      tag: ibanTag,
      start: ibanMatch.index,
      end: ibanMatch.index + value.length,
      confidence: 0.88,
      sample: value.slice(0, 32)
    });
    riskScore += 5;
  }
  return {
    tags: Array.from(tags.values()).sort(),
    findings,
    riskScore
  };
}

// src/background/service_worker.ts
var POLICY_REFRESH_ALARM = "umai_policy_refresh";
var QUEUE_FLUSH_ALARM = "umai_queue_flush";
var CONTROL_CENTER_CONNECT_PATH = "/extension/connect";
var TRUSTED_CONTROL_CENTER_ORIGINS = /* @__PURE__ */ new Set([
  "http://localhost:3000",
  "https://pocttconsole.umaisolutions.com",
  "https://umai-controlcenter-442107147924.europe-west3.run.app",
  "https://umai-controlcenter-mhkvrwuj2q-ey.a.run.app",
  "https://duvarai-controlcenter-442107147924.europe-west3.run.app",
  "https://duvarai-controlcenter-mhkvrwuj2q-ey.a.run.app"
]);
var CAPTURE_TAB_URLS = [
  "https://chatgpt.com/*",
  "https://chat.openai.com/*",
  "https://gemini.google.com/*",
  "https://claude.ai/*"
];
function isTrustedExternalSender(sender) {
  if (!sender.url) {
    return false;
  }
  try {
    const senderUrl = new URL(sender.url);
    const origin = senderUrl.origin.toLowerCase();
    const trustedOrigin = TRUSTED_CONTROL_CENTER_ORIGINS.has(origin);
    const validPath = senderUrl.pathname === CONTROL_CENTER_CONNECT_PATH || senderUrl.pathname.startsWith(`${CONTROL_CENTER_CONNECT_PATH}/`);
    return trustedOrigin && validPath;
  } catch (_error) {
    return false;
  }
}
function sanitizedRuntimeState(nextState) {
  if (!nextState.configured || !nextState.config) {
    return nextState;
  }
  return {
    configured: true,
    issues: [],
    config: {
      ...nextState.config,
      deviceToken: "hidden"
    }
  };
}
function queryCaptureTabs() {
  return new Promise((resolve) => {
    chrome.tabs.query({ url: CAPTURE_TAB_URLS }, (tabs) => {
      resolve(Array.isArray(tabs) ? tabs : []);
    });
  });
}
function reloadTab(tabId) {
  return new Promise((resolve) => {
    chrome.tabs.reload(tabId, () => {
      resolve();
    });
  });
}
async function refreshCaptureTabs() {
  try {
    const tabs = await queryCaptureTabs();
    await Promise.all(
      tabs.map((tab) => typeof tab.id === "number" ? reloadTab(tab.id) : Promise.resolve())
    );
  } catch (_error) {
  }
}
async function logPromptAttempted(payload, dlpTags, riskScore) {
  const runtimeState = getRuntimeState();
  if (!runtimeState.configured || !runtimeState.config) {
    return;
  }
  const protectedPayload = await applyCaptureMode(
    {
      prompt_text: payload.promptText,
      prompt_len: payload.promptText.length,
      attachments: sanitizeAttachmentsForCapture(payload.attachments ?? [], runtimeState.config.captureMode),
      dlp_tags: dlpTags,
      risk_score: riskScore
    },
    runtimeState.config.captureMode,
    ["prompt_text"]
  );
  const event = await buildEventEnvelope({
    config: runtimeState.config,
    eventType: "prompt_attempted",
    site: payload.site,
    url: payload.url,
    tabId: payload.tabId,
    userEmail: payload.userEmail,
    payload: protectedPayload
  });
  await enqueueEvent(event);
}
function sanitizeAttachmentsForCapture(attachments, captureMode) {
  return attachments.map((attachment) => {
    const next = { ...attachment };
    if (captureMode !== "full_content") {
      delete next.extracted_text;
      delete next.content_b64;
    }
    return next;
  });
}
async function logPolicyDecision(payload, decision) {
  const runtimeState = getRuntimeState();
  if (!runtimeState.configured || !runtimeState.config) {
    return;
  }
  const event = await buildEventEnvelope({
    config: runtimeState.config,
    eventType: "policy_decision",
    site: payload.site,
    url: payload.url,
    tabId: payload.tabId,
    userEmail: payload.userEmail,
    payload: {
      decision: decision.type,
      message: decision.message,
      rules_fired: decision.rulesFired,
      dlp_tags: decision.dlpTags,
      redactions: decision.redactions,
      require_justification: decision.requireJustification,
      min_justification_chars: decision.minJustificationChars
    }
  });
  await enqueueEvent(event);
}
function isRecord(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}
function stringArray(value) {
  if (!Array.isArray(value)) {
    return [];
  }
  return value.filter((entry) => typeof entry === "string" && entry.length > 0);
}
function normalizeRedactions(value) {
  if (!Array.isArray(value)) {
    return [];
  }
  return value.filter(isRecord).map((entry) => ({
    start: typeof entry.start === "number" ? entry.start : -1,
    end: typeof entry.end === "number" ? entry.end : -1,
    kind: typeof entry.kind === "string" ? entry.kind : "server"
  })).filter((entry) => entry.start >= 0 && entry.end >= entry.start);
}
function normalizeServerDecision(value, dlp) {
  if (!isRecord(value)) {
    return null;
  }
  const type = value.type;
  if (type !== "allow" && type !== "warn" && type !== "block" && type !== "redact" && type !== "justify") {
    return null;
  }
  const minChars = value.minJustificationChars;
  return {
    type,
    message: typeof value.message === "string" ? value.message : void 0,
    rulesFired: stringArray(value.rulesFired),
    dlpTags: stringArray(value.dlpTags).length > 0 ? stringArray(value.dlpTags) : dlp.tags,
    redactions: normalizeRedactions(value.redactions),
    redactedText: typeof value.redactedText === "string" ? value.redactedText : void 0,
    requireJustification: value.requireJustification === true,
    minJustificationChars: typeof minChars === "number" ? minChars : void 0
  };
}
function serverUnavailableDecision(message, dlp) {
  return {
    type: "block",
    message: `UMAI server guardrail evaluation failed closed. ${message}`,
    rulesFired: ["server_guardrail_unreachable"],
    dlpTags: dlp.tags,
    redactions: [],
    requireJustification: false
  };
}
function attachmentIncompleteDecision(attachments, dlp, action) {
  const tooLarge = attachments.find((attachment) => attachment.inspection_status === "too_large");
  if (tooLarge) {
    return {
      type: "block",
      message: `File ${tooLarge.filename} exceeds the organization file inspection size limit.`,
      rulesFired: ["attachment_too_large"],
      dlpTags: dlp.tags,
      redactions: [],
      requireJustification: false
    };
  }
  const incomplete = attachments.find(
    (attachment) => ["server_required", "pending", "unsupported", "extraction_failed", "truncated"].includes(
      attachment.inspection_status
    )
  );
  if (!incomplete) {
    return null;
  }
  const decisionType = action === "block" ? "block" : action === "warn" ? "warn" : "justify";
  return {
    type: decisionType,
    message: `File ${incomplete.filename} could not be fully inspected before AI submission.`,
    rulesFired: [`attachment_${incomplete.inspection_status}`],
    dlpTags: dlp.tags,
    redactions: [],
    requireJustification: decisionType === "justify",
    minJustificationChars: decisionType === "justify" ? 12 : void 0
  };
}
async function evaluatePromptOnServer(payload, dlp) {
  const runtimeState = getRuntimeState();
  const config = runtimeState.config;
  if (!runtimeState.configured || !config || !config.evaluateUrl) {
    throw new Error("Server evaluation is not configured.");
  }
  const response = await fetch(config.evaluateUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...buildAuthHeaders(config)
    },
    body: JSON.stringify({
      tenant_id: config.tenantId,
      site: payload.site,
      url: payload.url,
      tab_id: payload.tabId,
      prompt_text: payload.promptText,
      capture_mode: config.captureMode,
      user: {
        user_email: payload.userEmail ?? config.userEmail,
        user_idp_subject: config.userIdpSubject
      },
      device: {
        device_id: config.deviceId
      },
      attachments: payload.attachments ?? [],
      dlp,
      timeout_ms: 2500,
      allow_llm_calls: true
    }),
    cache: "no-store",
    credentials: "omit"
  });
  const responseBody = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = isRecord(responseBody) && typeof responseBody.message === "string" ? responseBody.message : `HTTP ${response.status}`;
    throw new Error(detail);
  }
  if (!isRecord(responseBody)) {
    throw new Error("Invalid server evaluation response.");
  }
  const decision = normalizeServerDecision(responseBody.decision, dlp);
  if (!decision) {
    throw new Error("Server evaluation decision is invalid.");
  }
  return decision;
}
async function onEvalPrompt(payload) {
  const runtimeState = getRuntimeState();
  if (!isUrlAllowed(payload.url)) {
    return {
      ok: false,
      configured: runtimeState.configured,
      message: "This domain is not allowed by enterprise policy.",
      decision: {
        type: "block",
        message: "Domain not allowed by policy.",
        rulesFired: ["allowlist_domain_check"],
        dlpTags: [],
        redactions: [],
        requireJustification: false
      }
    };
  }
  if (!runtimeState.configured || !runtimeState.config) {
    const missingDetails = runtimeState.issues.length > 0 ? runtimeState.issues.join(" ") : "Managed policy or local org connection not available.";
    return {
      ok: false,
      configured: false,
      message: "Extension is not configured. Connect organization from UMAI Control Center.",
      decision: {
        type: "block",
        message: `UMAI extension is not configured. ${missingDetails}`,
        rulesFired: ["managed_config_missing"],
        dlpTags: [],
        redactions: [],
        requireJustification: false
      }
    };
  }
  const dlp = scanTextForDlp(payload.promptText);
  const attachmentText = (payload.attachments ?? []).map((attachment) => attachment.extracted_text ?? "").filter((text) => text.length > 0).join("\n");
  const attachmentDlp = attachmentText ? scanTextForDlp(attachmentText) : void 0;
  const combinedDlp = attachmentDlp ? {
    tags: Array.from(/* @__PURE__ */ new Set([...dlp.tags, ...attachmentDlp.tags])).sort(),
    findings: [...dlp.findings, ...attachmentDlp.findings],
    riskScore: dlp.riskScore + attachmentDlp.riskScore
  } : dlp;
  let decision;
  const localAttachmentDecision = attachmentIncompleteDecision(
    payload.attachments ?? [],
    combinedDlp,
    runtimeState.config.fileInspection.incompleteAction
  );
  if (runtimeState.config.evaluationMode === "server" && !localAttachmentDecision?.rulesFired.includes("attachment_too_large")) {
    try {
      decision = await evaluatePromptOnServer(payload, combinedDlp);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unknown error.";
      decision = serverUnavailableDecision(message, combinedDlp);
    }
  } else if (localAttachmentDecision) {
    decision = localAttachmentDecision;
  } else {
    decision = evaluatePromptPolicy(`${payload.promptText}
${attachmentText}`, combinedDlp, getPolicyPack());
    if (attachmentDlp && decision.type === "redact" && attachmentDlp.tags.length > 0) {
      decision = {
        type: "justify",
        message: "An attachment contains sensitive data that cannot be redacted in the browser.",
        rulesFired: [...decision.rulesFired, "attachment_redaction_requires_approval"],
        dlpTags: combinedDlp.tags,
        redactions: [],
        requireJustification: true,
        minJustificationChars: 12
      };
    }
  }
  await logPromptAttempted(payload, combinedDlp.tags, combinedDlp.riskScore);
  await logPolicyDecision(payload, decision);
  return {
    ok: true,
    configured: true,
    decision
  };
}
async function onPromptSubmitted(payload) {
  const runtimeState = getRuntimeState();
  if (!runtimeState.configured || !runtimeState.config) {
    return;
  }
  const protectedPayload = await applyCaptureMode(
    {
      prompt_text: payload.promptText,
      prompt_len: payload.promptText.length,
      user_justification: payload.justification
    },
    runtimeState.config.captureMode,
    ["prompt_text", "user_justification"]
  );
  const event = await buildEventEnvelope({
    config: runtimeState.config,
    eventType: "prompt_submitted",
    site: payload.site,
    url: payload.url,
    tabId: payload.tabId,
    userEmail: payload.userEmail,
    payload: protectedPayload
  });
  await enqueueEvent(event);
}
async function onResponseFinal(payload) {
  const runtimeState = getRuntimeState();
  if (!runtimeState.configured || !runtimeState.config) {
    return;
  }
  const protectedPayload = await applyCaptureMode(
    {
      response_text: payload.responseText,
      response_len: payload.responseText.length,
      response_latency_ms: payload.latencyMs
    },
    runtimeState.config.captureMode,
    ["response_text"]
  );
  const event = await buildEventEnvelope({
    config: runtimeState.config,
    eventType: "response_final",
    site: payload.site,
    url: payload.url,
    tabId: payload.tabId,
    userEmail: payload.userEmail,
    payload: protectedPayload
  });
  await enqueueEvent(event);
}
async function onAdapterHealth(payload) {
  const runtimeState = getRuntimeState();
  if (!runtimeState.configured || !runtimeState.config) {
    return;
  }
  const event = await buildEventEnvelope({
    config: runtimeState.config,
    eventType: "adapter_health",
    site: payload.site,
    url: payload.url,
    tabId: payload.tabId,
    payload: {
      status: payload.status,
      details: payload.details
    }
  });
  await enqueueEvent(event);
}
async function runPostConfigRefresh() {
  await clearQueue();
  await resetEventChain();
  await refreshPolicyPack();
  await enforceBrowserSecurityAcrossTabs();
  await flushQueue();
}
async function bootstrap() {
  await initConfigModule();
  await initPolicyCache();
  await refreshPolicyPack();
  initBrowserSecurityGuardrails();
  await enforceBrowserSecurityAcrossTabs();
  startUploader();
  chrome.alarms.create(POLICY_REFRESH_ALARM, { periodInMinutes: 5 });
  chrome.alarms.create(QUEUE_FLUSH_ALARM, { periodInMinutes: 1 });
}
chrome.runtime.onInstalled.addListener((details) => {
  void bootstrap();
  if (details.reason === "install" || details.reason === "update") {
    void refreshCaptureTabs();
  }
});
chrome.runtime.onStartup.addListener(() => {
  void bootstrap();
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === POLICY_REFRESH_ALARM) {
    void refreshRuntimeConfig().then(() => refreshPolicyPack()).then(() => enforceBrowserSecurityAcrossTabs());
    return;
  }
  if (alarm.name === QUEUE_FLUSH_ALARM) {
    void flushQueue();
  }
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  void (async () => {
    try {
      if (message.type === "GET_CONFIG") {
        sendResponse({
          ok: true,
          config: sanitizedRuntimeState(getRuntimeState())
        });
        return;
      }
      if (message.type === "DISCONNECT_LOCAL_CONFIG") {
        const nextState = await clearLocalDevConfig();
        await clearQueue();
        await resetEventChain();
        await refreshPolicyPack();
        await enforceBrowserSecurityAcrossTabs();
        sendResponse({
          ok: true,
          config: sanitizedRuntimeState(nextState)
        });
        return;
      }
      if (message.type === "EVAL_PROMPT") {
        const result = await onEvalPrompt(message.payload);
        sendResponse({ ok: true, result });
        return;
      }
      if (message.type === "PROMPT_SUBMITTED") {
        await onPromptSubmitted(message.payload);
        sendResponse({ ok: true });
        return;
      }
      if (message.type === "RESPONSE_FINAL") {
        await onResponseFinal(message.payload);
        sendResponse({ ok: true });
        return;
      }
      if (message.type === "ADAPTER_HEALTH") {
        await onAdapterHealth(message.payload);
        sendResponse({ ok: true });
        return;
      }
      sendResponse({ ok: false, error: "Unknown message type." });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unexpected background error.";
      sendResponse({ ok: false, error: errorMessage });
    }
  })();
  return true;
});
chrome.runtime.onMessageExternal.addListener((rawMessage, sender, sendResponse) => {
  void (async () => {
    try {
      if (!isTrustedExternalSender(sender)) {
        sendResponse({ ok: false, error: "Untrusted sender." });
        return;
      }
      const message = rawMessage;
      if (!message || typeof message !== "object" || typeof message.type !== "string") {
        sendResponse({ ok: false, error: "Invalid message payload." });
        return;
      }
      if (message.type === "UMAI_PING" || message.type === "DUVARAI_PING") {
        sendResponse({
          ok: true,
          state: sanitizedRuntimeState(getRuntimeState())
        });
        return;
      }
      if (message.type === "UMAI_CONNECT" || message.type === "DUVARAI_CONNECT") {
        const nextState = await setLocalDevConfig(message.payload ?? {});
        if (!nextState.configured) {
          sendResponse({
            ok: false,
            error: "Config validation failed.",
            issues: nextState.issues
          });
          return;
        }
        sendResponse({
          ok: true,
          state: sanitizedRuntimeState(nextState)
        });
        void runPostConfigRefresh().catch(() => {
        });
        return;
      }
      if (message.type === "UMAI_DISCONNECT" || message.type === "DUVARAI_DISCONNECT") {
        const nextState = await clearLocalDevConfig();
        sendResponse({
          ok: true,
          state: sanitizedRuntimeState(nextState)
        });
        void (async () => {
          await clearQueue();
          await resetEventChain();
          await refreshPolicyPack();
          await enforceBrowserSecurityAcrossTabs();
        })().catch(() => {
        });
        return;
      }
      sendResponse({ ok: false, error: "Unknown external message type." });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unexpected external message error.";
      sendResponse({ ok: false, error: errorMessage });
    }
  })();
  return true;
});
void bootstrap();
//# sourceMappingURL=service_worker.js.map
